# star-hunt
A simple anonymous message sender like NGL!

How to install:
1. Clone the project
2. Import the SQL file to your MySQL server
3. Edit the SQLAlchemy config if necessary. It is located at the top part of app.py
4. Run app.py
5. Modify as you want!
   
